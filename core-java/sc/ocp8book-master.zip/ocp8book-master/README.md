# OCP8-Apress-Book
Source code for 'Oracle Certified Professional Java SE 8 Programmer Exam 1Z0-809: A Comprehensive OCPJP 8 Certification Guide' by SG Ganesh, Hari Kiran Kumar, and Tushar Sharma (http://www.apress.com/us/book/9781484218358) 

Also check out the supporting website for the book here: http://ocpjava.wordpress.com. Related slides are available in: www.slideshare.net/sgganesh 
