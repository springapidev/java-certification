/*------------------------------------------------------------------------------
 * Oracle Certified Professional Java SE 8 Programmer Exam 1Z0-809 
 * A Comprehensive OCPJP 8 Certification Guide
 * by SG Ganesh, Hari Kiran and Tushar Sharma
------------------------------------------------------------------------------*/

import java.util.*;

class UtilitiesTest {
	public static void main(String []args) {
	    List<Integer> intList = new LinkedList<>();
	    List<Double> dblList = new LinkedList<>();
	    System.out.println("First type: " + intList.getClass());
	    System.out.println("Second type:" + dblList.getClass());
	}
}
