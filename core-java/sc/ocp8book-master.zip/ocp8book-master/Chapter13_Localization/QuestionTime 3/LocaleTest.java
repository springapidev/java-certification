/*------------------------------------------------------------------------------
 * Oracle Certified Professional Java SE 8 Programmer Exam 1Z0-809 
 * A Comprehensive OCPJP 8 Certification Guide
 * by SG Ganesh, Hari Kiran and Tushar Sharma
------------------------------------------------------------------------------*/

import java.util.Locale; 

class LocaleTest {
	public static void main(String []args) { 
		Locale locale = new Locale("navi", "pandora");  //#1
		System.out.println(locale);
	}
  }

